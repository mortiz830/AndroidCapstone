package com.example.capstoneproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate: started");
    initImageBitMaps();
    }
    private void initImageBitMaps(){
        Log.d(TAG, "initImageBitMaps:Preparing bitmaps ");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 1");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 2");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 3");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 4");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 5");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 6");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 7");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 8");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 9");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 10");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 11");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 12");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 13");
        mImageUrls.add("https://www.wikihow.com/images/6/64/Stop-a-Dog-from-Jumping-Step-6-Version-2.jpg");
        mNames.add("Dog 14");
    initRecyclerView();
    }
private void initRecyclerView(){
RecyclerView recyclerView = findViewById(R.id.recycler_view);
RecyclerViewAdapter adapter = new RecyclerViewAdapter( this, mNames, mImageUrls);
recyclerView.setAdapter(adapter);
recyclerView.setLayoutManager(new LinearLayoutManager(this));

}
}
